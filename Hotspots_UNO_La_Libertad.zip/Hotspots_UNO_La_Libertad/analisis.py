"""Utilidades de datos y aprendizaje automático para Hotspots UNO."""
import io
import json
import re
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import requests
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.neighbors import KNeighborsClassifier

OVERPASS_URLS = [
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
# El área se identifica primero como relación administrativa dentro de El Salvador.
QUERY = '''[out:json][timeout:120];
area["ISO3166-1"="SV"]["admin_level"="2"]->.pais;
relation(area.pais)["boundary"="administrative"]["admin_level"="4"]["name"="La Libertad"];
map_to_area->.zona;
(
  nwr["amenity"="fuel"]["brand"~"UNO",i](area.zona);
  nwr["amenity"="fuel"]["name"~"UNO",i](area.zona);
  nwr["amenity"="fuel"]["operator"~"UNO",i](area.zona);
);
out center tags;
'''
COLS = ["osm_id", "name", "category", "latitude", "longitude", "city_municipality", "brand", "source"]

def es_uno(tags):
    """Conserva coincidencias de marca UNO como palabra completa."""
    return any(re.search(r"\bUNO\b", str(tags.get(key, "")), flags=re.I)
               for key in ("brand", "name", "operator"))

def normalizar_registros(registros):
    filas = []
    for obj in registros:
        tags = obj.get("tags") or {}
        if tags.get("amenity") != "fuel" or not es_uno(tags):
            continue
        centro = obj.get("center") or {}
        lat = obj.get("lat", centro.get("lat"))
        lon = obj.get("lon", centro.get("lon"))
        if lat is None or lon is None:
            continue
        # No se asignan municipios inventados a registros sin ese campo.
        municipio = tags.get("addr:city") or tags.get("addr:municipality") or tags.get("is_in:city") or ""
        filas.append({
            "osm_id": f'{obj.get("type", "node")}/{obj.get("id", "")}',
            "name": tags.get("name", "") or "Sin nombre en OSM",
            "category": "gasolinera",
            "latitude": lat,
            "longitude": lon,
            "city_municipality": municipio,
            "brand": tags.get("brand", ""),
            "source": "OpenStreetMap",
        })
    return limpiar(pd.DataFrame(filas, columns=COLS))

def limpiar(dataframe):
    df = dataframe.copy()
    for col in COLS:
        if col not in df:
            df[col] = ""
    df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")
    df = df.dropna(subset=["latitude", "longitude"])
    df = df[df.latitude.between(-90, 90) & df.longitude.between(-180, 180)]
    df = df.drop_duplicates(subset=["osm_id"])
    # Objetos OSM pueden representar la misma estación con nodo y polígono.
    df = df.drop_duplicates(subset=["latitude", "longitude"])
    return df[COLS].reset_index(drop=True)

def cargar_geojson(raw):
    geo = json.loads(raw)
    registros = []
    for i, f in enumerate(geo.get("features", [])):
        props = f.get("properties") or {}
        geometry = f.get("geometry") or {}
        tipo = geometry.get("type")
        coords = geometry.get("coordinates") or []
        if tipo != "Point" or len(coords) < 2:
            # Para polígonos exportados por OSM se prefiere usar JSON de Overpass,
            # que incluye 'center'. No se inventan centroides de geometrías complejas.
            continue
        tags = props.get("tags", props)
        osm_id = str(f.get("id", props.get("@id", i)))
        registros.append({"id": osm_id, "type": "feature", "lat": coords[1],
                          "lon": coords[0], "tags": tags})
    return normalizar_registros(registros)

def obtener_osm(timeout=145):
    errores = []
    for endpoint in OVERPASS_URLS:
        try:
            r = requests.post(endpoint, data={"data": QUERY}, timeout=timeout,
                              headers={"User-Agent": "HotspotsUNOAcademico/1.0"})
            r.raise_for_status()
            payload = r.json()
            if "elements" not in payload:
                raise ValueError("Respuesta sin campo elements")
            df = normalizar_registros(payload["elements"])
            return df, {"fecha_utc": datetime.now(timezone.utc).isoformat(),
                        "endpoint": endpoint, "consulta": QUERY,
                        "registros_osm": len(payload["elements"]),
                        "registros_validos": len(df)}
        except (requests.RequestException, ValueError) as ex:
            errores.append(f"{endpoint}: {ex}")
    raise RuntimeError("No se pudo consultar Overpass. " + " | ".join(errores))

def a_xy_km(df):
    # Aproximación equirectangular en km; apropiada para escala departamental.
    lat = df["latitude"].to_numpy(float)
    lon = df["longitude"].to_numpy(float)
    ref = float(lat.mean())
    x = lon * 111.32 * np.cos(np.radians(ref))
    y = lat * 110.574
    return np.column_stack((x, y)), ref

def agrupar(df, n_clusters):
    if len(df) < 2 or not (1 <= n_clusters <= len(df)):
        raise ValueError("La cantidad de grupos debe estar entre 1 y el total de estaciones")
    xy, ref = a_xy_km(df)
    modelo = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    resultado = df.copy()
    resultado["cluster"] = modelo.fit_predict(xy)
    centros = pd.DataFrame({
        "cluster": range(n_clusters),
        "latitude": modelo.cluster_centers_[:, 1] / 110.574,
        "longitude": modelo.cluster_centers_[:, 0] / (111.32 * np.cos(np.radians(ref))),
    })
    puntuacion = None
    if 2 <= n_clusters < len(df) and len(set(resultado.cluster)) > 1:
        puntuacion = float(silhouette_score(xy, resultado.cluster))
    return resultado, centros, puntuacion

def evaluar_k(df, max_k=6):
    if len(df) < 3:
        return pd.DataFrame(columns=["K", "silhouette"])
    xy, _ = a_xy_km(df)
    valores = []
    for k in range(2, min(max_k, len(df) - 1) + 1):
        labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(xy)
        if len(set(labels)) >= 2:
            valores.append({"K": k, "silhouette": silhouette_score(xy, labels)})
    return pd.DataFrame(valores)

def knn_punto(df_con_grupos, lat, lon, n_vecinos=3):
    if df_con_grupos.empty or "cluster" not in df_con_grupos:
        raise ValueError("Primero calcula K-Means")
    n_vecinos = max(1, min(int(n_vecinos), len(df_con_grupos)))
    coords = np.radians(df_con_grupos[["latitude", "longitude"]].to_numpy(float))
    clases = df_con_grupos["cluster"].to_numpy(int)
    knn = KNeighborsClassifier(n_neighbors=n_vecinos, metric="haversine", algorithm="ball_tree", weights="uniform")
    knn.fit(coords, clases)
    punto = np.radians([[float(lat), float(lon)]])
    distancias, indices = knn.kneighbors(punto)
    vecinos = df_con_grupos.iloc[indices[0]].copy()
    vecinos["distancia_km"] = distancias[0] * 6371.0088
    clase = int(knn.predict(punto)[0])
    return clase, vecinos.reset_index(drop=True)
