"""Aplicación sencilla de Hotspots UNO. Ejecutar: streamlit run app.py"""
import io
import json
from pathlib import Path

import folium
import pandas as pd
import streamlit as st
from folium.plugins import Fullscreen
from streamlit_folium import st_folium

from analisis import QUERY, agrupar, cargar_geojson, limpiar, evaluar_k, knn_punto, obtener_osm

st.set_page_config(page_title="Hotspots UNO | La Libertad", page_icon="📍", layout="wide")
st.title("Hotspots Comerciales — Gasolineras UNO")
st.caption("La Libertad, El Salvador | Prototipo académico con OpenStreetMap, K-Means y KNN")

CARPETA = Path(__file__).parent / "datos"
CARPETA.mkdir(exist_ok=True)
CSV = CARPETA / "estaciones_uno.csv"
META = CARPETA / "fuente.json"

with st.sidebar:
    st.header("1. Datos")
    st.write("Solo estaciones de servicio UNO registradas en OpenStreetMap.")
    if st.button("Consultar OpenStreetMap", use_container_width=True):
        with st.spinner("Consultando Overpass…"):
            try:
                df_nuevo, meta = obtener_osm()
                if df_nuevo.empty:
                    st.warning("La consulta no devolvió estaciones UNO. No se reemplazó el CSV anterior.")
                else:
                    df_nuevo.to_csv(CSV, index=False)
                    META.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                    st.success(f"Guardadas {len(df_nuevo)} estaciones.")
                    st.cache_data.clear()
            except Exception as exc:
                st.error(str(exc))
    subir = st.file_uploader("O cargar CSV / GeoJSON", type=["csv", "geojson", "json"])
    if subir is not None:
        try:
            contenido = subir.getvalue()
            if subir.name.lower().endswith(".csv"):
                datos = pd.read_csv(io.BytesIO(contenido))
                # CSV normalizado: solo registros de UNO; exigir campo de identificación.
                if not {"name", "latitude", "longitude"}.issubset(datos.columns):
                    raise ValueError("El CSV debe contener name, latitude, longitude")
                if "brand" not in datos.columns:
                    raise ValueError("El CSV debe incluir brand para verificar la marca UNO")
                filtro = datos[["brand", "name"]].fillna("").astype(str).apply(
                    lambda r: r.str.contains(r"\bUNO\b", case=False, regex=True).any(), axis=1)
                datos = datos.loc[filtro].copy()
                if "osm_id" not in datos:
                    datos["osm_id"] = [f"csv/{i}" for i in datos.index]
                df = limpiar(datos)
            else:
                df = cargar_geojson(contenido)
            st.info("Archivo cargado para esta sesión; no reemplaza el CSV local.")
        except Exception as exc:
            st.error(f"Archivo inválido: {exc}")
            st.stop()
    elif CSV.exists():
        try:
            df = limpiar(pd.read_csv(CSV))
        except Exception as exc:
            st.error(f"No se pudo leer {CSV.name}: {exc}")
            st.stop()
    else:
        df = pd.DataFrame()

if df.empty:
    st.warning("Todavía no hay datos reales cargados. Usa «Consultar OpenStreetMap» o carga un archivo con estaciones UNO.")
    st.info("Puedes descargar la consulta y ejecutarla en overpass-turbo.eu si el servicio falla.")
    st.code(QUERY, language="sql")
    st.stop()

st.subheader("Estaciones registradas")
c1, c2 = st.columns([1, 1])
c1.metric("Estaciones UNO", len(df))
c2.metric("Municipios informados en OSM", df["city_municipality"].replace("", pd.NA).nunique(dropna=True))
if META.exists() and subir is None:
    metadata = json.loads(META.read_text(encoding="utf-8"))
    st.caption(f"Fuente: OSM / Overpass | Extracción (UTC): {metadata.get('fecha_utc', 'No registrada')}")
eligibles = evaluar_k(df)

st.subheader("2. Agrupación K-Means")
if len(df) < 2:
    st.warning("K-Means requiere al menos dos estaciones distintas. Se muestra el mapa de puntos sin clasificar.")
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.stop()

sugerido = int(eligibles.loc[eligibles.silhouette.idxmax(), "K"]) if not eligibles.empty else 2
k = st.slider("Número de grupos (K)", 2, min(6, len(df)), min(sugerido, min(6, len(df))))
agrupadas, centroides, score = agrupar(df, k)
if score is not None:
    st.caption(f"Silhouette para K={k}: {score:.3f} (mayor suele indicar grupos más separados).")
if not eligibles.empty:
    with st.expander("Comparación de valores K"):
        st.dataframe(eligibles.round(3), hide_index=True, use_container_width=True)
        st.line_chart(eligibles.set_index("K")["silhouette"])

st.subheader("3. Analizar una nueva ubicación con KNN")
st.caption("KNN predice el grupo espacial de K-Means; no predice ventas, demanda ni viabilidad comercial.")
lat0 = float(df.latitude.mean())
lon0 = float(df.longitude.mean())
a, b, c = st.columns(3)
lat = a.number_input("Latitud propuesta", value=lat0, min_value=-90.0, max_value=90.0, format="%.6f")
lon = b.number_input("Longitud propuesta", value=lon0, min_value=-180.0, max_value=180.0, format="%.6f")
n_vec = c.slider("Vecinos para KNN", 1, min(9, len(df)), min(3, len(df)))
clase, vecinos = knn_punto(agrupadas, lat, lon, n_vec)
st.success(f"Grupo asignado a la nueva ubicación: {clase + 1} | Vecinos analizados: {len(vecinos)}")

st.subheader("4. Mapa interactivo")
colores = ["#2563eb", "#f97316", "#16a34a", "#a855f7", "#e11d48", "#0891b2"]
m = folium.Map(location=[lat0, lon0], zoom_start=10, control_scale=True, tiles="OpenStreetMap")
Fullscreen(position="topright").add_to(m)
for _, fila in agrupadas.iterrows():
    grupo = int(fila.cluster)
    folium.CircleMarker(
        [fila.latitude, fila.longitude], radius=7, fill=True, fill_opacity=.9,
        color="white", weight=1.5, fill_color=colores[grupo],
        tooltip=f"{fila['name']} | Grupo {grupo + 1}",
        popup=folium.Popup(f"<b>{fila['name']}</b><br>Gasolinera UNO<br>Grupo {grupo+1}<br>Municipio en OSM: {fila.city_municipality or 'No registrado'}", max_width=280),
    ).add_to(m)
for _, centro in centroides.iterrows():
    folium.Marker([centro.latitude, centro.longitude],
        icon=folium.Icon(color="gray", icon="info-sign"),
        tooltip=f"Centroide del grupo {int(centro.cluster)+1}").add_to(m)
folium.Marker([lat, lon], tooltip="Nueva ubicación", popup="Ubicación propuesta (hipotética)",
              icon=folium.Icon(color="red", icon="star")).add_to(m)
for _, vecino in vecinos.iterrows():
    folium.PolyLine([[lat, lon], [vecino.latitude, vecino.longitude]], color="#dc2626",
                    weight=2, opacity=.65, dash_array="5,6",
                    tooltip=f"{vecino.distancia_km:.2f} km (línea recta)").add_to(m)
st_folium(m, width=None, height=540, returned_objects=[])
st.caption("Leyenda: colores = grupos K-Means; marcadores grises = centroides; estrella roja = ubicación propuesta; líneas rojas = vecinos KNN.")
st.caption("Distancias de KNN: Haversine (línea recta sobre la esfera), no distancias por carretera.")

st.subheader("Vecinos más cercanos")
st.dataframe(vecinos[["name", "latitude", "longitude", "cluster", "distancia_km"]].rename(
    columns={"name":"Estación UNO", "cluster":"Grupo (desde 0)", "distancia_km":"Distancia (km)"}
).round(3), use_container_width=True, hide_index=True)
with st.expander("Tabla completa y exportación"):
    st.dataframe(agrupadas, use_container_width=True, hide_index=True)
    st.download_button("Descargar CSV de estaciones y grupos", data=agrupadas.to_csv(index=False).encode("utf-8-sig"),
                       file_name="estaciones_uno_clusters.csv", mime="text/csv")
st.info("Limitaciones: OSM puede omitir estaciones; la clasificación KNN utiliza pseudoetiquetas de K-Means, no etiquetas externas; se requiere estudio de tráfico, suelo, costos y demanda para tomar decisiones comerciales.")
