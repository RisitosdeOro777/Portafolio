# Hotspots Comerciales — Estaciones UNO en La Libertad

Prototipo académico sencillo. Usa solo estaciones UNO recogidas de OpenStreetMap, agrupación K-Means y KNN con pseudoetiquetas de grupo.

## Ejecutar en Windows

Abre PowerShell en esta carpeta y ejecuta:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Si PowerShell no deja activar el entorno, puedes ejecutar directamente:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

La aplicación se abre normalmente en http://localhost:8501.

## Conseguir datos reales

1. Presiona **Consultar OpenStreetMap** en la barra lateral. Necesitas conexión a Internet. Se guarda un CSV en `datos/estaciones_uno.csv` y metadatos de consulta en `datos/fuente.json`.
2. Si Overpass no responde, abre https://overpass-turbo.eu/, pega `consulta_overpass.txt`, ejecuta y exporta como GeoJSON. Carga ese archivo en la aplicación. La importación GeoJSON admite puntos; si la exportación contiene polígonos, se omiten hasta obtener sus centroides desde el JSON original de Overpass.
3. No se proporciona un dataset inventado: los datos deben descargarse de OSM. Si OSM tiene poca cobertura, el resultado será limitado.

## Notebook

Tras descargar el dataset desde la aplicación, ejecuta `jupyter notebook` y abre `hotspots_uno.ipynb`. El notebook lee el CSV local y genera grupos, análisis y mapa HTML.

## Diccionario de campos

| Columna | Descripción |
|---|---|
| osm_id | Identificador del elemento OSM |
| name | Nombre OSM (puede faltar) |
| category | Gasolinera |
| latitude, longitude | Coordenadas geográficas WGS84 |
| city_municipality | Municipio/ciudad, vacío si no consta en OSM |
| brand | Marca informada en OSM, puede estar vacía |
| source | OpenStreetMap |

## Método y limitaciones

- La consulta está limitada por el límite administrativo de La Libertad (`admin_level=4`) en OSM.
- K-Means usa una aproximación equirectangular a kilómetros, apropiada para analizar distancias locales de forma exploratoria. K se compara por silhouette si hay suficientes puntos.
- KNN usa Haversine y como etiquetas los clusters de K-Means: son **pseudoetiquetas**, no zonas comerciales verificadas. No es una evaluación independiente ni pronostica ventas.
- El número de registros depende de las etiquetas existentes en OSM y la fecha de consulta.
- Las distancias son en línea recta, no rutas de carretera.
- Antes de decidir una inversión se requiere contraste con tráfico, demanda, propiedad, normas y trabajo de campo.

Fuente: OpenStreetMap contributors, datos ODbL. Herramienta de consulta: Overpass API.
